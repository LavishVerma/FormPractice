package com.CP.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.CP.model.Rider;
import com.CP.service.RiderService;

@Controller
@RequestMapping("/rider")
public class RiderController {

	@Autowired
private	RiderService riderService;
	
	@RequestMapping("/showform")
    public ModelAndView showorm(ModelAndView mv)
    {
		
		mv.addObject("Rider", new Rider());
		mv.setViewName("NewFile");
		return mv;
		
    }
	
	@RequestMapping("/login")
    public ModelAndView loginform1(ModelAndView mv)
    {
		
		mv.addObject("Rider", new Rider());
		mv.setViewName("login");
		return mv;
		
    }
	
	
	@RequestMapping("/welcome")
    public ModelAndView loginform2(ModelAndView mv)
    {
		
		mv.addObject("Rider", new Rider());
		mv.setViewName("welcome");
		return mv;
		
    }
	
	@RequestMapping("/FindAride")
    public ModelAndView loginform3(ModelAndView mv)
    {
		
		mv.addObject("Rider", new Rider());
		mv.setViewName("FindAride");
		return mv;
		
    }
	
	@RequestMapping("/processform")
	public String processForm(@Valid @ModelAttribute("Rider") Rider  rider1, BindingResult bindingresult,ModelAndView mv,
			HttpSession session
			)
	{
		System.out.println(rider1.getAge()
				+"\n" +rider1.getFirstname()+"\n" + rider1.getGender()+"\n"+
				rider1.getLastname()+"\n"+rider1.getPassword()+"\n" + rider1.getUserid()
				+"\n"+ rider1.getContact()+"\n");
		
		
		
		if(bindingresult.hasErrors())
		{
			
			System.out.println( bindingresult);
			return "success";
		}
		else
		{
			session.setAttribute("session", "authorised");
			 System.out.println("inside else");
		            riderService.addRider(rider1);    
		            return "register";
		}
		
		
	}
	
	@RequestMapping("loginprocess")
	public String login()
	{
		return "success";
	}
	
}
