package com.CP.dao;

import com.CP.model.Rider;

public interface RiderDao {
	public void addRider(Rider rider);
	   /* public void updateRider(Rider rider);
	    public Rider getRiderById(Integer rider);
	    public List<Rider> listRiders();
	    public void removeRider(Integer id);*/

}
