package com.CP.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.CP.model.Rider;

@Repository
public class RiderDaoImpl  implements  RiderDao{

	private SessionFactory sessionFactory;
	
    @Autowired
    public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Override
	public void addRider(Rider rider) {
		// TODO Auto-generated method stub
		
		System.out.println("helodao");
		 sessionFactory.getCurrentSession().save(rider);
	}

}
