package com.CP.service;

import java.util.List;

import com.CP.model.Rider;

public interface RiderService {

	public void addRider(Rider rider);
   /* public void updateRider(Rider rider);
    public Rider getRiderById(Integer rider);
    public List<Rider> listRiders();
    public void removeRider(Integer id);*/
	
}
