package com.CP.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.CP.dao.RiderDao;
import com.CP.dao.RiderDaoImpl;
import com.CP.model.Rider;

@Service
public class RiderServiceImpl implements RiderService {
 
	@Autowired
	private RiderDaoImpl riderdao;
	
	
	//@Qualifier(value = "bookDao")
   /* public void setRiderDao(RiderDaoImpl riderdao) {
		this.riderdao = riderdao;
	}*/
	
	@Transactional
	public void addRider(Rider rider) {
		// TODO Auto-generated method stub
		System.out.println("hello service");
		riderdao.addRider(rider);
	}

	
}
