package com.CP.validation;



import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class CustomeOne  implements ConstraintValidator<CustomOne, String>{

	private String coursePrefix;
	
	@Override
	public void initialize(CustomOne theCustomOne) {
		// TODO Auto-generated method stub
		coursePrefix=theCustomOne.value();
	}

	@Override
	public boolean isValid(String theCode, ConstraintValidatorContext theConstraintValidatorContext) {
		boolean result= theCode.startsWith(coursePrefix);
		return result;
	}



}
