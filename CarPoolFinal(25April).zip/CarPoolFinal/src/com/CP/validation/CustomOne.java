package com.CP.validation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.ConstraintValidator;
import javax.validation.Payload;

@Constraint(validatedBy=CustomeOne.class)
@Target({ElementType.METHOD, ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)


public @interface CustomOne {
   //define the value for the error
	public String value() default "One";
   
   //defining the error messages
	public String message() default"must start with One";
	
	public Class<?>[] groups() default{};
	
	public Class<? extends Payload>[] payload() default{};
	
}
