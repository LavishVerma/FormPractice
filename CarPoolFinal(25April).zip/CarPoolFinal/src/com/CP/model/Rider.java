package com.CP.model;


import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.*;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name="Rider")
public class Rider {
	 /*private List<String> genderList;

	
	public List<String> getGenderList() {
		
		genderList=new ArrayList<String>();
		genderList.add("Male");
		genderList.add("Female");
		return genderList;
	}*/
	@Id
	@Column(name = "USER_ID")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	@Column(name="IDD")
	@NotEmpty(message="is required")
	private String userid;
	
	@Column(name="FIRST_NAME")
	@NotEmpty(message="is required")
	private String firstname;
	
	@Column(name="LAST_NAME")
	@NotEmpty(message="is required")
	private String lastname;
	
	@Column(name="PASSWORD")
	@NotEmpty(message="is required")
  private String password;
	
	@Column(name="AGE")
      private Integer age;
	
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	@NotEmpty(message="is required")
  private String gender;
	
	
 


/*  @NotEmpty(message="is required")
  private String postalcode;*/
	
 /* @NotNull(message="is required")*/
	@Column(name="CONTACT")
  private Integer contact;
	
/*  @NotEmpty(message="is required")
  private String email;*/
	
	
	
public String getUserid() {
	return userid;
}
public void setUserid(String username) {
	this.userid = username;
}
public String getFirstname() {
	return firstname;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}


public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}

public Integer getContact() {
	return contact;
}
public void setContact(Integer contact) {
	this.contact = contact;
}
/*public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}*/



  
  
  
}
