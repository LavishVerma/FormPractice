package com.infotech.service.impl;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Random;

import org.json.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infotech.dao.StudentDAO;
import com.infotech.model.FindArideModel;
import com.infotech.model.OfferArideModel;
import com.infotech.model.registermodal;
import com.infotech.service.StudentService;

@Service("studentService")
public class StudentServiceImpl implements StudentService {
	
	@Autowired
	private StudentDAO studentDAO;
	
	public void setStudentDAO(StudentDAO studentDAO) {
		this.studentDAO = studentDAO;
	}
	
	public StudentDAO getStudentDAO() {
		return studentDAO;
	}
	
	public boolean registerStudent(registermodal student) {
						
			boolean saveStudent = getStudentDAO().saveStudent(student);
			
			if(saveStudent)
				return saveStudent;
						
		return false;
	}

	
	public boolean validateStudentCredential(String email, String password) {
		boolean flag=true;
		flag=getStudentDAO().getStudentDetailsByEmailAndPassword(email, password);
		return flag;
	}

	
	public List<OfferArideModel> registerRide(FindArideModel ride) {
		
     
      
       Random ran=new Random();
       ride.setFindid(Integer.toString(ran.nextInt(((89999)+1)+10000)));
      
       List<OfferArideModel> list=getStudentDAO().saveRide(ride);
       //System.out.println(list);
       for(int i=0;i<list.size();i++)
       {
    	   boolean flag1=false,flag2=false;
    	   float floatpick=DistanceCalculator(ride.getFindpickupaddress(),list.get(i).getOfferpickupaddress()) ;
    	   float floatdrop=DistanceCalculator(ride.getFinddropaddress(),list.get(i).getOfferdropaddress());
    		
    	   System.out.println("FLOATPICK"+floatpick);
    	   System.out.println("FLOATDROP"+floatdrop);
    	   
    	   if((floatpick<=4.0 &&floatdrop<=15))
    	   {
    		   System.out.println("INSIDE OUTER IF");
    		   if(!((Integer.parseInt(ride.getFindnoofseats()))<=(Integer.parseInt(list.get(i).getOffervacancy()))))
    		   {
    			   System.out.println("INSIDE INNER IF");
    			   list.remove(i);
    			   i--;
    		   }
    	   } 
    	   else
    	   {
    		   list.remove(i);
			   i--; 
    	   }
    	  
    	   
    	  
    		
    	   
    	   
      
       }
        
   
		return list;
	}

	public boolean registerOffer(OfferArideModel offer) {
	
		 boolean flag=false;
		 Random ran=new Random();
	       offer.setOfferid(Integer.toString(ran.nextInt(((89999)+1)+10000)));
	       flag=getStudentDAO().saveOffer(offer);
			return flag;
	}

	public boolean emailValidation(String email) {
		if(getStudentDAO().emailValidation(email))
		{ 
			return true;
		}
		return false;
	}

	public List<OfferArideModel> getInfoFromDB() {
	  List<OfferArideModel> list=getStudentDAO().getInfoFromDB();
		return list;
	}
	
	public float DistanceCalculator(String pick,String drop)
	{
		//System.out.println(pick+"QWERTY"+drop);
		 URL url;
	       String line, outputString = "",result="",value1="";
	       try {
	              url = new URL("https://maps.googleapis.com/maps/api/distancematrix/json?origins="+pick.replaceAll(" ", "+")+"&destinations="+drop.replaceAll(" ", "+")+"&key=AIzaSyAdw6UUh4KD4S_xpi7iugMJv9npBs474yA");
// System.out.println("pahunch gaya");
	       HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	       conn.setRequestMethod("GET");
	      
	       BufferedReader reader = new BufferedReader(
	       new InputStreamReader(conn.getInputStream()));
	       while ((line = reader.readLine()) != null) {
	            outputString += line;
	       }
	           //System.out.println(outputString);
	            JSONObject json1= new JSONObject(outputString);	       
	            JSONArray element1 =json1.getJSONArray("rows");
	            value1=element1.toString().substring(1, element1.toString().length()-1);
	            //System.out.println(value1);
	            JSONObject json2= new JSONObject(value1);
	            JSONArray element2 =json2.getJSONArray("elements");
	            String value2=element2.toString().substring(1, element2.toString().length()-1);
	           // System.out.println(value2);
	            JSONObject json3= new JSONObject(value2);
	            String element3 =json3.optString("distance");
	          // System.out.println(element3);
	            JSONObject json4= new JSONObject(element3);
	            result =json4.getString("text").substring(0,json4.getString("text").indexOf(" "));
	            
	   		   // System.out.println(result);
	       
	             } catch (Exception e) 
	               {       
	                e.printStackTrace();
	               }
	      // System.out.println("JSIOGHIOFNWHJGEKhvnLKEbGVUeOFVNlb"+result);
	       return (Float.parseFloat(result));
	}

	public String getUserNameThroughEmail(String email) {
		String result=getStudentDAO().getUserNameThroughEmail(email);
		return result;
	}

	public registermodal getProfileDetails(String email) {
	 return getStudentDAO().getProfileDetails(email);
	}

	public boolean updateProfile(registermodal profile,String id) {
		boolean flag=false;
		
		flag=getStudentDAO().updateProfile(profile,id);
		return flag;
	}
}


	

