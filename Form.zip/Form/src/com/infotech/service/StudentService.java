package com.infotech.service;


import com.infotech.model.registermodal;

public interface StudentService {
	public abstract registermodal validateStudentCredential(String email,	String password);
	public abstract boolean registerStudent(registermodal student);

}