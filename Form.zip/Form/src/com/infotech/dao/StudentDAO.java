package com.infotech.dao;

import com.infotech.model.registermodal;

public interface StudentDAO {
	public abstract boolean saveStudent(registermodal student);
	public registermodal getStudentDetailsByEmailAndPassword(String email,String password);
}
