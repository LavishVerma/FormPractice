package com.infotech.Validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class PasswordConstraintValidator implements ConstraintValidator<Password, String> {

	
	public void initialize(Password arg0) {
		// TODO Auto-generated method stub
		
	}

	
	public boolean isValid(String s, ConstraintValidatorContext cvc) {
		
//		
//		(			# Start of group
//				  (?=.*\d)		#   must contains one digit from 0-9
//				  (?=.*[a-z])		#   must contains one lowercase characters
//				  (?=.*[A-Z])		#   must contains one uppercase characters
//				  (?=.*[@#$%])		#   must contains one special symbols in the list "@#$%"
//				              .		#     match anything with previous condition checking
//				                {6,20}	#        length at least 6 characters and maximum of 20	
////				)			# End of group
	   Pattern pattern=null;
		   Matcher matcher=null;
		   
	String PASSWORD_PATTERN ="((?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[,~,!,@,#,$,%,^,&,*,(,),-,_,=,+,[,{,],},|,;,:,<,>,/,?].*$).{8,15})";
		pattern = Pattern.compile(PASSWORD_PATTERN);
		matcher = pattern.matcher(s);
		
//	     if(s.getConfirmpassword().equals(s.getPassword()))
//	    	 return false;
//	     else
//	    	 return true;
		//System.out.println(s);  
		return matcher.matches(); 
	}

}

