package com.infotech.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

import com.infotech.Validator.Password;
@Entity
@Table(name="UserRegister")
public class registermodal {
                @GeneratedValue
                @Id
                private Integer id;
                
                public Integer getId() {
                                return id;
                }
                
                @NotEmpty(message="FirstName  must not be blank")
                @Pattern(regexp="^[A-Za-z]+$" ,message="Invalid FirstName")
                @Size(min=1,max=50,message="FirstName must be between 1 to 50 characters")
                private String firstname;
                
                @NotEmpty(message="LastName  must not be blank")
                @Pattern(regexp="^[A-Za-z]+$" ,message="Invalid LastName")
                @Size(min=1,max=50,message="LastName must be between 1 to 50 characters")
                private String lastname;
                
                @NotEmpty(message="Age must not be blank")
                @Pattern(regexp="^[0-9]+$" ,message="Invalid Age")
                @Size(min=1,max=2,message="Age must be less than 100")
                private String age;
                
                /*@NotEmpty(message="UserId must not be blank")
                @Pattern(regexp="^[A-Za-z0-9]+$" ,message="Invalid UserID")
                @Size(min=1,max=15,message="UserID must be between 1 to 15 characters")*/
                @NotEmpty
                @Email
                private String email;
                
                @Password
                private String password;
                
                
                @Size(min=10,max=10,message="ContactNumber must be 10 characters")
                @Pattern(regexp="^[0-9]+$" ,message="Invalid ContactNumber")
                private String contactnumber;
                
                @NotEmpty(message="Gender  must not be blank")
                private String gender;
                
                public String getFirstname() {
                                return firstname;
                }
                
                
                public void setFirstname(String firstname) {
                                this.firstname = firstname;
                }
                public String getLastname() {
                                return lastname;
                }
                public void setLastname(String lastname) {
                                this.lastname = lastname;
                }
                public String getAge() {
                                return age;
                }
                public void setAge(String age) {
                                this.age = age;
                }
                
                public String getEmail() {
                                return email;
                }
                public void setEmail(String email) {
                                this.email = email;
                }
                public String getPassword() {
                                return password;
                }
                public void setPassword(String password) {
                                this.password = password;
                }
                public String getContactnumber() {
                                return contactnumber;
                }
                public void setContactnumber(String contactnumber) {
                                this.contactnumber = contactnumber;
                }
                public String getGender() {
                                return gender;
                }
                public void setGender(String gender) {
                                this.gender = gender;
                }
                

                
}
