package com.infotech.dao.impl;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.infotech.dao.StudentDAO;
import com.infotech.model.FindArideModel;
import com.infotech.model.OfferArideModel;
import com.infotech.model.registermodal;

@Repository("studentDAO")
public class StudentDAOImpl implements StudentDAO {
	@Autowired
	SessionFactory sf;
    
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}
	/////////////////////////////////////////////////////////////////
	@Transactional
	public boolean saveStudent(registermodal student) {
	//int id=(Integer)hibernateTemplate.save(student);
		boolean flag=false;
		int id=(Integer)sf.openSession().save(student);
	    if(id>0)
	    	flag=true;
	    
	return flag;
	
	}
	///////////////////////////////////////////////////////////////////
	@SuppressWarnings("unchecked")
	public boolean getStudentDetailsByEmailAndPassword(String email,String password)
	{
//		System.out.println("   "+ email+"   "+password);
//		StudentCredential sc=hibernateTemplate.get(StudentCredential.class,email);
//		if(sc.getPassword().equals(password))
//			return true;
//		else
//			return false;
		
		List<Object> list=sf.openSession().createQuery("from registermodal as u where u.email=? and u.password=?").setParameter(0,email).setParameter(1, password).list();
		boolean userFound =false;
		
		if(list!=null&&list.size()>0)
		userFound=true;
		return userFound;
//		
//		DetachedCriteria detachedCriteria =  DetachedCriteria.forClass(registermodal.class);
//		detachedCriteria.add(Restrictions.eq("email", email));
//		detachedCriteria.add(Restrictions.eq("password", password));
//		List<r> findByCriteria = (List<registermodal>) hibernateTemplate.findByCriteria(detachedCriteria);
//		if(findByCriteria !=null && findByCriteria.size()>0)
//		return findByCriteria.get(0);
//		else
//			return null;  
	}
	
	@Transactional
	public List<OfferArideModel> saveRide(FindArideModel ride) {
		boolean flag=false;
		List<OfferArideModel> list=sf.openSession().createQuery("from OfferArideModel where offerDate=?").setParameter(0,ride.getFinddate()).list();
		//System.out.println("fbhwsgbfeiufvhieu"+list);
		//int id=(Integer)sf.openSession().save(ride);
		//if(id>0)
			//flag=true;
		return list;
	}
	@Transactional
	public boolean saveOffer(OfferArideModel offer) {
		// TODO Auto-generated method stub
		boolean flag=false;
		int id=(Integer)sf.openSession().save(offer);
		if(id>0)
			flag=true;
		return flag;
	}
	
	
	public boolean emailValidation(String email) {
		Query q=sf.openSession().createQuery("select email from registermodal"); 
		List list=q.list();
		//System.out.println("  "+list);
		if((list.contains(email)))
				return true;
		return false;
	}
	public List getInfoFromDB() {
		
		System.out.println("hellooo");
		Query q=sf.openSession().createQuery("from OfferArideModel");
		List<OfferArideModel> list=(List<OfferArideModel>)q.list();
//		for(OfferArideModel studs: list)				
//		System.out.println(studs);
		
	
		
				return list;
	}
	public String getUserNameThroughEmail(String email) {
		Query q=sf.openSession().createQuery("select firstname,lastname from registermodal where email=?").setParameter(0,email);
		List list= q.list();
		Iterator it=list.iterator();
		Object[] o=(Object[])it.next();
		String result=(String)o[0]+" "+(String)o[1];
		
		    System.out.println(result);
		
		
			
				return result;
	}
	public boolean updateProfile(registermodal profile,String id)
	{
		System.out.println("QWERTYPLIUYDDL;LIYTRDCVNMLOIUYTFVBNKIUYTGFVBNKIUYGBNKUGV"+profile);
	//sf.openSession().saveOrUpdate(profile);
		Query q=sf.openSession().createQuery("update registermodal set firstname=? , lastname=?, age=? , "
				+ " gender=? , password=? , contactnumber=? where id=?")
		.setParameter(0, profile.getFirstname())
		.setParameter(1, profile.getLastname())
		.setParameter(2, profile.getAge())
		.setParameter(3, profile.getGender())
		.setParameter(4, profile.getPassword())
		.setParameter(5, profile.getContactnumber())
		.setParameter(6, Integer.parseInt(id));
		q.executeUpdate();
		return false;
	}
	
	public registermodal getProfileDetails(String email)
	{
		Query q=sf.openSession().createQuery("from registermodal where email=?").setParameter(0, email);
		registermodal reg=(registermodal)q.uniqueResult();
		//System.out.println(" dhrjtjsrhhjrjtd"+reg.getId());
		return reg;
	}
}
