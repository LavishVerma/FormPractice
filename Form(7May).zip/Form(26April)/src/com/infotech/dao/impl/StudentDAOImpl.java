package com.infotech.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.infotech.dao.StudentDAO;
import com.infotech.model.FindArideModel;
import com.infotech.model.OfferArideModel;
import com.infotech.model.registermodal;

@Repository("studentDAO")
public class StudentDAOImpl implements StudentDAO {
	@Autowired
	SessionFactory sf;
    
	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}
	/////////////////////////////////////////////////////////////////
	@Transactional
	public boolean saveStudent(registermodal student) {
	//int id=(Integer)hibernateTemplate.save(student);
		boolean flag=false;
		int id=(Integer)sf.openSession().save(student);
	    if(id>0)
	    	flag=true;
	    
	return flag;
	
	}
	///////////////////////////////////////////////////////////////////
	@SuppressWarnings("unchecked")
	public boolean getStudentDetailsByEmailAndPassword(String email,String password)
	{
//		System.out.println("   "+ email+"   "+password);
//		StudentCredential sc=hibernateTemplate.get(StudentCredential.class,email);
//		if(sc.getPassword().equals(password))
//			return true;
//		else
//			return false;
		
		List<Object> list=sf.openSession().createQuery("from registermodal as u where u.email=? and u.password=?").setParameter(0,email).setParameter(1, password).list();
		boolean userFound =false;
		
		if(list!=null&&list.size()>0)
		userFound=true;
		return userFound;
//		
//		DetachedCriteria detachedCriteria =  DetachedCriteria.forClass(registermodal.class);
//		detachedCriteria.add(Restrictions.eq("email", email));
//		detachedCriteria.add(Restrictions.eq("password", password));
//		List<r> findByCriteria = (List<registermodal>) hibernateTemplate.findByCriteria(detachedCriteria);
//		if(findByCriteria !=null && findByCriteria.size()>0)
//		return findByCriteria.get(0);
//		else
//			return null;
	}
	
	@Transactional
	public boolean saveRide(FindArideModel ride) {
		boolean flag=false;
		int id=(Integer)sf.openSession().save(ride);
		if(id>0)
			flag=true;
		return flag;
	}
	@Transactional
	public boolean saveOffer(OfferArideModel offer) {
		// TODO Auto-generated method stub
		boolean flag=false;
		int id=(Integer)sf.openSession().save(offer);
		if(id>0)
			flag=true;
		return flag;
	}
	
	
	public boolean emailValidation(String email) {
		Query q=sf.openSession().createQuery("select email from registermodal"); 
		List list=q.list();
		//System.out.println("  "+list);
		if((list.contains(email)))
				return true;
		return false;
	}
	public List getInfoFromDB() {
		
		System.out.println("hellooo");
		Query q=sf.openSession().createQuery("from OfferArideModel");
		List<OfferArideModel> list=(List<OfferArideModel>)q.list();
//		for(OfferArideModel studs: list)				
//		System.out.println(studs);
		
	
		
				return list;
	}
}
