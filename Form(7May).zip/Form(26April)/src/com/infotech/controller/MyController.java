package com.infotech.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.infotech.model.OfferArideModel;
import com.infotech.model.registermodal;
import com.infotech.service.StudentService;

@Controller
public class MyController {
/////////////////////////////////////////////////////////////////////////////////////////////////////	
	@Autowired
	private StudentService studentService;

	public void setStudentService(StudentService studentService) {
		this.studentService = studentService;
	}
	
	public StudentService getStudentService() {
		return studentService;
	}

///////////////////////////////////////////////////////////
	/*
	 * @RequestMapping(value="/FindAride",method=RequestMethod.GET) 
	 * public String FindAride(Model model) 
	 * { 
	 * model.addAttribute("RideModelAttribute",new FindArideModel()); 
	 * return "FindAride"; 
	 * }
	 * 
	 * @RequestMapping(value="/RideAction",method=RequestMethod.POST) public
	 * ModelAndView RidePost(@Valid @ModelAttribute("RideModelAttribute")
	 * FindArideModel ride,BindingResult result,Model model) { ModelAndView
	 * modelAndView = new ModelAndView(); if(result.hasErrors()) {
	 * modelAndView.setViewName("FindAride"); return modelAndView; } boolean
	 * flag=false; flag=getStudentService().registerRide(ride); if(flag)
	 * modelAndView.setViewName("welcome"); else
	 * modelAndView.setViewName("notFound");
	 * 
	 * return modelAndView; }
	 * //////////////////////////////////////////////////////////////////
	 * 
	 * @RequestMapping(value="/offeraride",method=RequestMethod.GET) public String
	 * offeraride(Model model) { model.addAttribute("OfferModelAttribute",new
	 * OfferArideModel()); return "offeraride"; }
	 * 
	 * @RequestMapping(value="/OfferAction",method=RequestMethod.POST)
	 *  public
	 * ModelAndView RideOffer(@Valid @ModelAttribute("OfferModelAttribute")
	 * OfferArideModel offer,BindingResult result,Model model) { ModelAndView
	 * modelAndView = new ModelAndView(); if(result.hasErrors()) {
	 * modelAndView.setViewName("offeraride"); return modelAndView; } boolean
	 * flag=false; flag=getStudentService().registerOffer(offer); if(flag)
	 * modelAndView.setViewName("welcome"); else
	 * modelAndView.setViewName("notFound");
	 * 
	 * return modelAndView; }
	 */
//////////////////////////////////////////////////////////////////
@ModelAttribute
public void addAttributes1(Model model) 
{
	ArrayList agelist=  new ArrayList();
		agelist.add("18-28");
		agelist.add("28-38");
		agelist.add("38-48");
		agelist.add("48-58");
		agelist.add("58-68");
		agelist.add("68-78");
		agelist.add("78-88");
		agelist.add("88-98");
		agelist.add("98-108");
		agelist.add("108-118");
		agelist.add("118-120");
		model.addAttribute("agelist",agelist);
		
		ArrayList genderlist=  new ArrayList();
		genderlist.add("Male");
		genderlist.add("Female");
		model.addAttribute("genderlist",genderlist);
		
		
		ArrayList timelist=new ArrayList();
		timelist.add("0:00");
		timelist.add("1:00");
		timelist.add("2:00");
		timelist.add("3:00");
		timelist.add("4:00");
		timelist.add("5:00");
		timelist.add("6:00");
		timelist.add("7:00");
		timelist.add("8:00");
		timelist.add("9:00");
		timelist.add("10:00");
		timelist.add("11:00");
		timelist.add("12:00");
		timelist.add("13:00");
		timelist.add("14:00");
		timelist.add("15:00");
		timelist.add("16:00");
		timelist.add("17:00");
		timelist.add("18:00");
		timelist.add("19:00");
		timelist.add("20:00");
		timelist.add("21:00");
		timelist.add("22:00");
		timelist.add("23:00");		
		model.addAttribute("timelist",timelist);
		
		ArrayList picklist=new ArrayList();
		picklist.add("Gachibowli");
		picklist.add("Kondapur");
		picklist.add("Madhapur");
		picklist.add("Kukatpally");
		picklist.add("Jubilee Hills");
		model.addAttribute("picklist", picklist);
		
		ArrayList droplist=new ArrayList();
		droplist.add("Nampally Railway station");
		droplist.add("Rajiv Gandhi Airport");
		droplist.add("Miyapur Bus Stand");
		droplist.add("Secunderabad Railway Station");
		droplist.add("Hitech MMTS");
		model.addAttribute("droplist", droplist);
		
		ArrayList seatslist=new ArrayList();
		seatslist.add("1");
		seatslist.add("2");
		seatslist.add("3");
		seatslist.add("4");
		seatslist.add("5");
		seatslist.add("6");
		
		model.addAttribute("seatslist",seatslist);
		
		ArrayList vacancy=new ArrayList();
		vacancy.add("1");
		vacancy.add("2");
		vacancy.add("3");
		vacancy.add("4");
		vacancy.add("5");
		vacancy.add("6");
		model.addAttribute("vacancy",vacancy);
		
		
  }
//////////////////////////////////////////////////////////	
	@RequestMapping(value ="/" ,method=RequestMethod.GET)
	public String homePage(Model model){
		
		List<OfferArideModel> list=getStudentService().getInfoFromDB();
		
		model.addAttribute("list", list);
		
		//return "dashboard";
		return "NewFile";
	}
/////////////////////////////////////////////////////////
	@RequestMapping(value ="/offeraride" ,method=RequestMethod.GET)
	public String OfferArideGET(Model model){
		model.addAttribute("OfferModel", new OfferArideModel());
		return "offeraride";
	}
////////////////////////////////////////////////////////////////
	@RequestMapping(value ="/offeraride" ,method=RequestMethod.POST)	
	public ModelAndView OfferAridePOST(@Valid @ModelAttribute("OfferModel") OfferArideModel OfferModel,BindingResult result)
	{ModelAndView model=new ModelAndView();
		if(result.hasErrors())
		{
			model.setViewName("offeraride");
			return model;
		}	
		boolean flag=false;
		flag=getStudentService().registerOffer(OfferModel);
		if(flag)
		{
			model.setViewName("dashboard");
			return model;
		}
		model.setViewName("notFound");
		return model;
	}
//////////////////////////////////////////////////////////
	@RequestMapping(value ="/welcome" ,method=RequestMethod.GET)
	public String WelcomePage(){
		return "welcome";
	}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@RequestMapping(value ="/loginandsignup" ,method=RequestMethod.GET)
	public String loginPage(Model model){
		
		  model.addAttribute("student", new registermodal());		 
		 		 
		return "login";
	}
/////////////////////////////////////////////////////////////////////////////////////////
	/*
	 * @RequestMapping(value="/login",method=RequestMethod.GET) public String
	 * loginAndSignup(@ModelAttribute("loginCredential") StudentCredential
	 * studentCredential,@ModelAttribute("student") registermodal
	 * student,BindingResult result,Model model) { //model.addAttribute("student",
	 * new registermodal()); //model.addAttribute("loginCredential", new
	 * StudentCredential()); return "success"; }
	 */
/////////////////////////////////////////////////////////////////////
	@RequestMapping(value ="/loginrider" ,method = {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView loginSuccess(ModelMap map, @RequestParam("loginemail") String loginemail,@RequestParam("loginpassword") String loginpassword,Model model){
		ModelAndView modelAndView = new ModelAndView();
		model.addAttribute("student",new registermodal());
		if(loginemail.isEmpty()&&loginpassword.isEmpty())
		{
			map.put("login", "Login must not be Empty");
			map.put("password","Password must not be Empty");
			modelAndView.setViewName("login");
			return modelAndView;
		}
		
		if(loginemail.isEmpty())
		{
		map.put("login", "Login must not be Empty");
		modelAndView.setViewName("login");
		return modelAndView;
		}
		
		if(loginpassword.isEmpty())
		{
		map.put("password","Password must not be Empty");
		modelAndView.setViewName("login");
		return modelAndView;			
		}
		
		boolean flag=true;
		flag=getStudentService().validateStudentCredential(loginemail, loginpassword);
		System.out.println(flag);
		if(flag)
		{
			modelAndView.setViewName("success");
			return modelAndView;
		}
		
		
		modelAndView.setViewName("notFound");
		return modelAndView;			
	}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	@RequestMapping(value ="/FindAride" ,method=RequestMethod.GET)
	public String FindAridePage(Model model){
		//model.addAttribute("student", new registermodal());
		return "FindAride";
	}
////////////////////////////////
	@RequestMapping(value ="/registerrider" ,method = {RequestMethod.GET,RequestMethod.POST})
	public  ModelAndView registerSuccess(ModelMap mod,@RequestParam("confirmpassword") String confpassword,@Valid  @ModelAttribute("student") registermodal student, BindingResult bindingResult,Model model){
		
		System.out.println(student.getFirstname()+" "+student.getLastname()+"  "+student.getContactnumber()+" "+student.getAge()+" "+student.getEmail()+" "+student.getGender()+" "+student.getPassword());
		boolean flag1=bindingResult.hasErrors();
		boolean flag2=!(confpassword.equals(student.getPassword()));
		boolean flag3=getStudentService().emailValidation(student.getEmail());
		
		if(flag1)
		{
			return new ModelAndView("login");
		}
		if(flag2)
		{
			mod.put("confirm", "Password Does not Match.");
			return new ModelAndView("login");
		}
		
		
		if(flag3)
		{
			mod.put("failed", "Email Already Exist.");
						return new ModelAndView("login");
		}
		getStudentService().registerStudent(student);
		
		ModelAndView modelAndView = new ModelAndView("welcome");
		modelAndView.addObject("student", student);
		return modelAndView;
	}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////	
}
