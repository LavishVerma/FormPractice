package com.infotech.model;


	
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.Id;
	import javax.persistence.Table;
	import javax.validation.constraints.Pattern;
	import javax.validation.constraints.Size;

	import org.hibernate.validator.constraints.NotEmpty;
	@Entity
	@Table(name="offeraride")
	public class OfferArideModel {
		@Id
		@GeneratedValue
		private Integer id;
		
		public Integer getId() {
			return id;
		}
		
		private String offerid;
		
		public String getOfferid() {
			return offerid;
		}

		public void setOfferid(String offerid) {
			this.offerid = offerid;
		}

		@NotEmpty(message="PickupAddress  must not be blank")
		private String offerpickupaddress;
		
		@NotEmpty(message="PickupDescription  must not be blank")
		private String offerpickupdescription;
				
		
		@NotEmpty(message="DropAddress must not be blank")
		private String offerdropaddress;
		
		@NotEmpty(message="DropDescription  must not be blank")
		private String offerdropdescription;
		
		@NotEmpty(message="Date must not be blank")
		private String offerDate;
			
		@NotEmpty(message="Time must not be blank")
		private String offertime;
		
		@NotEmpty(message="Seats must not be blank")
		private String offervacancy;

		public String getOfferpickupaddress() {
			return offerpickupaddress;
		}

		public void setOfferpickupaddress(String offerpickupaddress) {
			this.offerpickupaddress = offerpickupaddress;
		}

		public String getOfferpickupdescription() {
			return offerpickupdescription;
		}

		public void setOfferpickupdescription(String offerpickupdescription) {
			this.offerpickupdescription = offerpickupdescription;
		}

		public String getOfferdropaddress() {
			return offerdropaddress;
		}

		public void setOfferdropaddress(String offerdropaddress) {
			this.offerdropaddress = offerdropaddress;
		}

		public String getOfferdropdescription() {
			return offerdropdescription;
		}

		public void setOfferdropdescription(String offerdropdescription) {
			this.offerdropdescription = offerdropdescription;
		}

		public String getOfferDate() {
			return offerDate;
		}

		public void setOfferDate(String offerDate) {
			this.offerDate = offerDate;
		}

		public String getOffertime() {
			return offertime;
		}

		public void setOffertime(String offertime) {
			this.offertime = offertime;
		}

		public String getOffervacancy() {
			return offervacancy;
		}

		public void setOffervacancy(String offervacancy) {
			this.offervacancy = offervacancy;
		}

		

		

		

		
		
		
		

	}



