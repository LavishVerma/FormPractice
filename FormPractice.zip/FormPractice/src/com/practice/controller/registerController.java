package com.practice.controller;

import java.util.ArrayList;

import javax.annotation.Generated;
import javax.annotation.PostConstruct;
import javax.validation.Valid;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import com.practice.modals.registermodal;
import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;

@Controller
@RequestMapping("/login")
public class registerController {
	
	 @ModelAttribute
	  public void addAttributes(Model model) 
	 {
		 ArrayList genderlist=  new ArrayList();
			genderlist.add("Male");
			genderlist.add("Female");
			model.addAttribute("genderlist",genderlist);
	    }
	
	@RequestMapping(method = RequestMethod.GET)
	public String DisplayLogin(Model model)
	{
		registermodal register=new registermodal();
		model.addAttribute("register",register);
		
//		ArrayList genderlist=  new ArrayList();
//		genderlist.add("Male");
//		genderlist.add("Female");
//		model.addAttribute("genderlist",genderlist);
//		
		return "user_register";
	}
	
	@RequestMapping(method = RequestMethod.POST)
	public String ProcessRegister(@Valid @ModelAttribute("register") registermodal register,BindingResult result,Model model)
	{
	
	    if(result.hasErrors())
		{
			return "user_register";
		}
		
	    Configuration con=new Configuration().configure().addAnnotatedClass(registermodal.class);
	    SessionFactory sf=con.buildSessionFactory();
	    Session session=sf.openSession();
	    Transaction tx=session.beginTransaction();
	    session.save(register);
	    tx.commit();
		
//		System.out.println(register.getFirstname());
//		System.out.println(register.getLastname());
//		System.out.println(register.getUserid());
//		System.out.println(register.getAge());
//		System.out.println(register.getPassword());
//		System.out.println(register.getContactnumber());
//		System.out.println(register.getGender());
		
		return "success";
	}
}
