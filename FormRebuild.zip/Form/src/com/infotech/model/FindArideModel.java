package com.infotech.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="rideRegister")
public class FindArideModel {
	@Id
	@GeneratedValue
	private Integer id;
	
	public Integer getId() {
		return id;
	}
	@NotEmpty(message="FirstName  must not be blank")
	@Pattern(regexp="^[A-Za-z]+$" ,message="Invalid FirstName")
	@Size(min=1,max=50,message="FirstName must be between 1 to 50 characters")
	private String firstname;
	
	@NotEmpty(message="LastName  must not be blank")
	@Pattern(regexp="^[A-Za-z]+$" ,message="Invalid LastName")
	@Size(min=1,max=50,message="LastName must be between 1 to 50 characters")
	private String lastname;
	
	@NotEmpty(message="Age must not be blank")
	private String age;
	
	@NotEmpty(message="Gender  must not be blank")
	private String gender;
	
	@Size(min=10,max=10,message="ContactNumber must be 10 characters")
	@Pattern(regexp="^[0-9]+$" ,message="Invalid ContactNumber")
	private String contactnumber;
	
	@NotEmpty(message="UserId must not be blank")
	@Pattern(regexp="^[A-Za-z0-9]+$" ,message="Invalid UserID")
	@Size(min=1,max=15,message="UserID must be between 1 to 15 characters")
	private String userid;
	
	@NotEmpty(message="Enter PickUp Point")
	private String pickupaddress;
	
	@NotEmpty(message="Enter PickUp City")
	@Pattern(regexp="^[A-Za-z]+$" ,message="Invalid pickup city")
	private String pickcity;
	
	@NotEmpty(message="Enter Zipcode")
	@Pattern(regexp="^[0-9]+$" ,message="Invalid Zipcode")
	@Size(min=7,max=7,message="Zipcode must be 7 digit")
	private String zipcode;
	
	@NotEmpty(message="Enter Drop Point")
	private String dropaddress;
	
	@NotEmpty(message="Enter Drop City")
	@Pattern(regexp="^[A-Za-z]+$" ,message="Invalid drop city")
	private String dropcity;
	
	
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getContactnumber() {
		return contactnumber;
	}
	public void setContactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPickupaddress() {
		return pickupaddress;
	}
	public void setPickupaddress(String pickupaddress) {
		this.pickupaddress = pickupaddress;
	}
	public String getPickcity() {
		return pickcity;
	}
	public void setPickcity(String pickcity) {
		this.pickcity = pickcity;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getDropaddress() {
		return dropaddress;
	}
	public void setDropaddress(String dropaddress) {
		this.dropaddress = dropaddress;
	}
	public String getDropcity() {
		return dropcity;
	}
	public void setDropcity(String dropcity) {
		this.dropcity = dropcity;
	}

}
