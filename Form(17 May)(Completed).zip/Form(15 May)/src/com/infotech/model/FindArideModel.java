package com.infotech.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name="findaride")
public class FindArideModel {
	@Id
	@GeneratedValue
	private Integer id;
	
	public Integer getId() {
		return id;
	}
	
	@NotEmpty(message="PickupAddress  must not be blank")
	private String findpickupaddress;
	
	@NotEmpty(message="PickupDescription  must not be blank")
	private String findpickupdescription;
			
	
	@NotEmpty(message="DropAddress must not be blank")
	private String finddropaddress;
	
	@NotEmpty(message="DropDescription  must not be blank")
	private String finddropdescription;
	
	@NotEmpty(message="Time must not be blank")
	private String findtime;
	
	@NotEmpty(message="Date must not be blank")
	private String finddate;
	
	@NotEmpty(message="Seats must not be blank")
	private String findnoofseats;
	
	@NotEmpty(message="Distance must not be blank")
	private String finddistance;
	
	public String getFindpickupaddress() {
		return findpickupaddress;
	}

	public void setFindpickupaddress(String findpickupaddress) {
		this.findpickupaddress = findpickupaddress;
	}

	public String getFindpickupdescription() {
		return findpickupdescription;
	}

	public void setFindpickupdescription(String findpickupdescription) {
		this.findpickupdescription = findpickupdescription;
	}

	public String getFinddropaddress() {
		return finddropaddress;
	}

	public void setFinddropaddress(String finddropaddress) {
		this.finddropaddress = finddropaddress;
	}

	public String getFinddropdescription() {
		return finddropdescription;
	}

	public void setFinddropdescription(String finddropdescription) {
		this.finddropdescription = finddropdescription;
	}

	public String getFindtime() {
		return findtime;
	}

	public void setFindtime(String findtime) {
		this.findtime = findtime;
	}

	public String getFinddate() {
		return finddate;
	}

	public void setFinddate(String finddate) {
		this.finddate = finddate;
	}

	public String getFindnoofseats() {
		return findnoofseats;
	}

	public void setFindnoofseats(String findnoofseats) {
		this.findnoofseats = findnoofseats;
	}

	public String getFinddistance() {
		return finddistance;
	}

	public void setFinddistance(String finddistance) {
		this.finddistance = finddistance;
	}

	private String findid;
	
	public String getFindid() {
		return findid;
	}

	public void setFindid(String findid) {
		this.findid = findid;
	}

	
	
	

	

	
	
	
	

}
