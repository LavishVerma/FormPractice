package com.infotech.dao;

import java.util.List;

import com.infotech.model.FindArideModel;
import com.infotech.model.OfferArideModel;
import com.infotech.model.registermodal;

public interface StudentDAO {
	public abstract boolean saveStudent(registermodal student);
	public boolean emailValidation(String email);
	public boolean getStudentDetailsByEmailAndPassword(String email,String password);
	public List<OfferArideModel> saveRide(FindArideModel ride);
	public boolean saveOffer(OfferArideModel offer);
	public List<OfferArideModel> getInfoFromDB();
}
