package com.social.imageApp.controllers.account;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

public class AccountUpdateController {
	


}
