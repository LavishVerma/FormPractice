package com.social.imageApp.controllers.upload;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class UploadSingleMediaController {
	@GetMapping("/singlemedia")
	public String home()
	{
		return "singlemedia";
	}

}
