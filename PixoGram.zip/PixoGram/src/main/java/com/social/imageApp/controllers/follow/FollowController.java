package com.social.imageApp.controllers.follow;

public class FollowController {

}
