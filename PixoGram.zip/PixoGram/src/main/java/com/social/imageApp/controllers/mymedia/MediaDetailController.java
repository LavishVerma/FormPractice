package com.social.imageApp.controllers.mymedia;

public class MediaDetailController {

}
